# PARS WMS CORE (Mobile Full) - Replace All
## Admin Login
- ID: admin
- PW: 1234

# PARS WMS CORE AB Integrated Final

Upload and run on Railway.
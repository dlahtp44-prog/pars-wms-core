
STEP7 권한/계정 (초기 간편 버전)

- 세션 기반 로그인 (JWT 미사용 → Railway 안정)
- 역할: admin / user
- 보호 페이지: 엑셀, 출력, 라벨
- 기본 계정:
  admin / admin123
